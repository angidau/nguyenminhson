package Page;

import org.openqa.selenium.By;

public class login_Pages {
    public By userid =By.xpath("//input[@name='uid']");
    public By password =By.xpath("//input[@name='password']");
    public By loginBtn =By.xpath("//input[@name='btnLogin']");

}
